package tugas4;

public class Student {
private String Nrp;

public String getNrp() {
	return Nrp;
}

public void setNrp(String nrp) {
	Nrp = nrp;
}
}
