package tugas4;


public class Lingkaran {
 private int jari2;

 public Lingkaran(int jari2) {
     this.jari2 = jari2;
 }

 public int getJari2() {
     return jari2;
 }


 public void setJari2(int jari2) {
     this.jari2 = jari2;
 }
}

