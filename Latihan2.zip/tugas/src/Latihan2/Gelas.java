package Latihan2;

public class Gelas {
	
	private String warna;
	
	public Gelas(String w) {
		warna = w;
	}

	public String getWarna() {
		return warna;
	}

	public void setWarna(String warna) {
		this.warna = warna;
	}

}
