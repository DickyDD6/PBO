package tugas11;

public class InterfaceMain {
  
  public static void main(String[] args) {
    KartuElektronik kartu = new KartuElektronik("TF111", "123");
    System.out.println("Otentikasi:" + kartu.otentikasi("123"));
  }

}
