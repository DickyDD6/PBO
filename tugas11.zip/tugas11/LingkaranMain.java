package tugas11;

public class LingkaranMain {
  public static void main(String[] args) {
    System.out.println("== Lingkaran ==");
    Lingkaran lingkaran = new Lingkaran(10);
    System.out.println("Jari-jari: " + lingkaran.getJari2());
    System.out.println("Luas: " + lingkaran.luas());
    System.out.println();
    System.out.println("== Tabung ==");
    Tabung tabung = new Tabung(10, 5);
    System.out.println("Jari-jari: " + tabung.getJari2());
    System.out.println("Tinggi: " + tabung.getTinggi());
    System.out.println("Luas: " + tabung.luas());
  }
}
