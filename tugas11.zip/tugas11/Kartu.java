package tugas11;

public interface Kartu {
  public boolean otentikasi(String pin);
  public String encode(String pin);
}
